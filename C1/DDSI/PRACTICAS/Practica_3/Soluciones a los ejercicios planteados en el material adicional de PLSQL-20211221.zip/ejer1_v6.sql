begin
	dbms_output.put_line ('Resultado para 34558.2: ' || cuota_integra (34558.2));
	dbms_output.put_line ('Resultado para 120202.42: ' || cuota_integra (120202.42));
end;
/
