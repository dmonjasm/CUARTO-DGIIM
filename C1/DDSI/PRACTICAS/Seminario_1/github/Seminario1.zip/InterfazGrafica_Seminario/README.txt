Para compilar el programa, ejecute la orden make dentro de este directorio
Si quiere ejecutar el programa ponga la orden make ejecucion
Requisitos:
	-Se requiere una versión JDK 11 o superior, pues se ha utilizado como Driver Manager ojdbc11.jar
	-Se requieres utilizar la orden jar, luego se debe tener instalado (si no se tiene sudo apt-get install default-jdk)
