#!/bin/bash
#Daniel Monjas Miguélez
#17/03/2022

mpicc pi_paralelo.c -o pi_paralelo

inicio=214748362

for ((i = 1 ; i <= 10 ; i++));
do
	sbatch -Aacap -p acap -N 1 -n 2 -c 1 --hint=nomultithread --exclusive --wrap "mpirun -np 2 ./pi_paralelo $inicio"
	echo -e "\n"
	((inicio+=214748364))
done 
